﻿namespace Celeste.Mod.CommunalHelper.Utils;

public enum CurveType
{
    Quadratic = 2,
    Cubic = 3,
}
