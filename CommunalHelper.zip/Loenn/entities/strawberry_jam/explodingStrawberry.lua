﻿local explodingStrawberry = {}

explodingStrawberry.name = "CommunalHelper/SJ/ExplodingStrawberry"
explodingStrawberry.texture = "collectables/strawberry/normal00"
explodingStrawberry.placements = {
    {
        name = "strawberry",
        data = {}
    }
}

return explodingStrawberry