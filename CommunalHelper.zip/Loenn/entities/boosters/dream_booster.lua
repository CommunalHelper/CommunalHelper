local dreamBooster = {}

-- unfortunately, CommunalHelper/DreamBooster existed before the addition of the any-direction Dream Booster
-- so that one's called CommunalHelper/DreamBoosterAny.
dreamBooster.name = "CommunalHelper/DreamBoosterAny"
dreamBooster.depth = -11000

dreamBooster.placements = {
    name = "dream_booster"
}

dreamBooster.texture = "objects/CommunalHelper/boosters/dreamBooster/idle00"

return dreamBooster
