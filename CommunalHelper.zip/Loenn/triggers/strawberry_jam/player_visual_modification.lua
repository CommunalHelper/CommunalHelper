return {
    name = "CommunalHelper/PlayerVisualModTrigger",
    placements = {
        name = "trigger",
        data = {
            revertOnLeave = false,
            modifier = "Skateboard"
        }
    }
}