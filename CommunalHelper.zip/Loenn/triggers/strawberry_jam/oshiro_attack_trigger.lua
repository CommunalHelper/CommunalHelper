return {
    name = "CommunalHelper/SJ/OshiroAttackTimeTrigger",
    placements = {
        name = "trigger",
        data = {
            Enable = true
        }
    }
}