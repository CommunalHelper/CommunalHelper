return {
    name = "CommunalHelper/SJ/ShowHitboxTrigger",
    placements = {
        name = "trigger",
        data = {
            typeNames = "Celeste.CrystalStaticSpinner"
        }
    }
}
