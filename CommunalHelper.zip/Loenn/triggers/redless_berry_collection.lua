return {
    name = "CommunalHelper/RedlessBerryCollection",
    placements = {
        name = "trigger"
    }
}
