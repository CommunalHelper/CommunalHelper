return {
    name = "CommunalHelper/StopLightningControllerTrigger",
    placements = {
        name = "trigger"
    }
}
