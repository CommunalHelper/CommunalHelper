return {
    name = "CommunalHelper/SoundAreaTrigger",
    nodeLimits = {1, 1},
    placements = {
        name = "trigger",
        data = {
            event = ""
        }
    }
}
