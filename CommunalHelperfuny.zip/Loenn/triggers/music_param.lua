return {
    name = "CommunalHelper/MusicParamTrigger",
    placements = {
        name = "trigger",
        data = {
            param = "",
            enterValue = 1.0,
            exitValue = 0.0
        }
    }
}
