# CommunalHelper
[![Build](https://github.com/CommunalHelper/CommunalHelper/actions/workflows/build-push.yml/badge.svg)](https://github.com/CommunalHelper/CommunalHelper/actions/workflows/build-push.yml)

A collection of new mechanics for the game Celeste

Documentation available on the [CommunalHelper GitHub Wiki](https://github.com/CommunalHelper/CommunalHelper/wiki).

### If your mod depends on CommunalHelper code, please see [this issue](https://github.com/CommunalHelper/CommunalHelper/issues/56).
