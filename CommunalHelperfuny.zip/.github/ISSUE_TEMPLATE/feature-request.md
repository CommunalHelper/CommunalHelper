---
name: Feature Request
about: Suggest an idea for the mod
title: ''
labels: idea
assignees: ''

---

**Describe your request:**




- [ ] Is your request a change to an existing feature?
  - What feature?
- [ ] Is this something that will be used for an upcoming collab/contest?
  - When would you need it by?

**Additional details:**
Add any other details, screenshots or concept art about the feature request here.
